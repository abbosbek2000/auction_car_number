package uz.developer.project.admin;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;
import uz.developer.project.model.entity.RegionCarNumber;
import uz.developer.project.payload.RegionCarNumberDTO;
import uz.developer.project.repository.RegionCarNumberRepository;
import uz.developer.project.repository.UserRepository;
import uz.developer.project.service.LoginService;
import uz.developer.project.service.RegionCarNumberService;
import javax.validation.Valid;


@Controller
public class AddRegionCarNumber {
    private final RegionCarNumberService regionCarNumberService;
    private final RegionCarNumberRepository regionCarNumberRepository;
    private final LoginService loginService;
    private final UserRepository userRepository;

    @Autowired
    public AddRegionCarNumber(RegionCarNumberService regionCarNumberService, RegionCarNumberRepository regionCarNumberRepository, LoginService loginService, UserRepository userRepository) {
        this.regionCarNumberService = regionCarNumberService;
        this.regionCarNumberRepository = regionCarNumberRepository;
        this.loginService = loginService;
        this.userRepository = userRepository;
    }

    @GetMapping("/admin")
    public String list(Model model) {
        model.addAttribute("listRegionCarNumberDTO", regionCarNumberRepository.findAll());
        return "index";
    }


    @GetMapping("/")
    public String main(Model model) {
        model.addAttribute("listRegionCarNumberDTO", regionCarNumberRepository.findAll());
        return "main";
    }

    @GetMapping("/save/car/number")
    public String addCar(Model model) {

        RegionCarNumberDTO regionCarNumberDTO = new RegionCarNumberDTO();
        model.addAttribute("regionCarNumberDTO", regionCarNumberDTO);
        return "save_car_number";
    }

    @PostMapping("/save/car/number")
    public String saveRegionCar(@Valid @ModelAttribute("regionCarNumberDTO") RegionCarNumberDTO regionCarNumberDTO, BindingResult result) {
        if (result.hasErrors()) {
            return "save_car_number";
        }
        regionCarNumberService.addRegionNumber(regionCarNumberDTO);
        return "redirect:/admin";
    }

    @PostMapping("/edit/car/number")
    public String editRegionCar(@Valid @ModelAttribute("regionCarNumberDTO") RegionCarNumber regionCarNumber, BindingResult result) {
        if (result.hasErrors()) {
            return "save_car_number";
        }
        regionCarNumberService.editRegionNumber(regionCarNumber);
        return "redirect:/admin";
    }

    @GetMapping("/car/update/{id}")
    public String updateCarNumber(@PathVariable(value = "id") Long id, Model model) {
        //get
        RegionCarNumber regionCarNumber = regionCarNumberService.getRegionCarById(id);
        model.addAttribute("regionCarNumber", regionCarNumber);
        return "update_region_car";
    }

    @GetMapping("/car/delete/{id}")
    public String deleteCarNumber(@PathVariable(value = "id") Long id) {
        //get
        regionCarNumberService.deleteCarNumber(id);
        return "redirect:/admin";
    }


    //Podrobnoe car number
    @GetMapping("/podrobnoe/car/{id}")
    public String podrobnorCarNumber(@PathVariable(value = "id") Long id, Model model) {
        //get
        RegionCarNumber regionCarNumber = regionCarNumberService.getRegionCarById(id);
        model.addAttribute("regionCarNumber", regionCarNumber);
        return "podropnoe";
    }

}
