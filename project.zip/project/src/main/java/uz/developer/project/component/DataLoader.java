package uz.developer.project.component;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;
import uz.developer.project.model.entity.Region;

import uz.developer.project.model.enums.Regions;
import uz.developer.project.repository.RegionRepository;
import uz.developer.project.utils.AppConst;

import java.util.Arrays;
@Component
public class DataLoader implements CommandLineRunner {
    @Autowired
    RegionRepository regionRepository;
    @Value("${spring.datasource.initialization-mode}")
    private String initialMode;

    @Override
    public void run(String... args) throws Exception {
        if (initialMode.equals("always")){
            Regions[] regions = Regions.values();
            regionRepository.save(new Region(
                    AppConst.ANDIJON
            ));
            regionRepository.save(new Region(
                    AppConst.BUXORO
            ));
            regionRepository.save(new Region(
                    AppConst.FERGANA
            ));
            regionRepository.save(new Region(
                    AppConst.JIZZAH
            ));
            regionRepository.save(new Region(
                    AppConst.XORAZM
            ));
            regionRepository.save(new Region(
                    AppConst.NAMANGAN
            ));
            regionRepository.save(new Region(
                    AppConst.NAVOIY
            ));
            regionRepository.save(new Region(
                    AppConst.QASHQADARYO
            ));
            regionRepository.save(new Region(
                    AppConst.NUKUS
            ));
            regionRepository.save(new Region(
                    AppConst.SAMARQAND
            ));
            regionRepository.save(new Region(
                    AppConst.SIRDARYO
            ));
            regionRepository.save(new Region(
                    AppConst.SURXONDARYO
            ));
            regionRepository.save(new Region(
                    AppConst.TOSHKENVIL
            ));
        }
    }
}
