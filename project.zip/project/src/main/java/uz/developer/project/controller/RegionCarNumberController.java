package uz.developer.project.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;
import uz.developer.project.apiresponse.ApiResponse;
import uz.developer.project.payload.RegionCarNumberDTO;
import uz.developer.project.service.RegionCarNumberService;
import javax.validation.Valid;
@Component
@Controller
@RequestMapping("/api/car")
public class RegionCarNumberController {
    @Autowired
    RegionCarNumberService regionCarNumberService;
    @PostMapping("/number")
    public HttpEntity<?> addCarNumber(@Valid @RequestBody RegionCarNumberDTO regionCarNumberDTO){
        ApiResponse apiResponse = regionCarNumberService.addRegionNumber(regionCarNumberDTO);
        if (apiResponse.isSuccess())
            return ResponseEntity.ok("Saqlandi");
        return ResponseEntity.ok("");
    }

}
