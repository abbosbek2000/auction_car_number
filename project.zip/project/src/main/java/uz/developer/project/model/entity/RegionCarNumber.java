package uz.developer.project.model.entity;
import com.fasterxml.jackson.annotation.JsonFormat;
import jdk.jfr.Timestamp;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import org.hibernate.annotations.CreationTimestamp;
import uz.developer.project.model.template.AbsEntity;

import javax.persistence.*;
import javax.validation.constraints.NotNull;
import java.math.BigDecimal;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;

@EqualsAndHashCode(callSuper = true)
@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity(name = "region_car")
public class RegionCarNumber extends AbsEntity {
    private String firstLetter;

    private String regionNumber;

    private String allCarNumber;

    @Column(nullable = false)
    @NotNull(message = "price null bo'lishi mumkin emas")
    private BigDecimal price;

    private Double carNumber;

    private String twoLetter;

}
