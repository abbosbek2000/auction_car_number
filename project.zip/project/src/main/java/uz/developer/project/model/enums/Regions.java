package uz.developer.project.model.enums;

public enum Regions {
    TASHKENT,
    ANDIJAN,
    FERGANA,
    NAMANGAN
}
