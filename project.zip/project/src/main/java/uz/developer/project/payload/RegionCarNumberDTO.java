package uz.developer.project.payload;
import com.fasterxml.jackson.annotation.JsonFormat;
import jdk.jfr.Timestamp;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.validator.constraints.Length;
import uz.developer.project.model.entity.RegionCarNumber;

import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import java.math.BigDecimal;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;


@Data
@AllArgsConstructor
@NoArgsConstructor

public class RegionCarNumberDTO {

    @NotBlank(message = "region car number null bo'lishi mumkin emas")
    private String regionNumber;

    @Size(min = 1,max = 1,message ="raqam birinchi harfi bitta bo'ladi" )
    private String firstLetter;

    private String allCarNumber;

    @NotNull(message = "price null bo'lishi mumkin emas")
    private BigDecimal price;

    @NotNull(message = "car number null bo'lishi mumkin emas")
    private Double carNumber ;
    Date createdAt = new Date();
    public void setCreatedDate(Date createdDate) {
        createdDate = createdAt;
    }



    @Length(min = 1, max = 2, message = "size ga etibor bering")
    @NotNull(message = "raqamning ikkitalik raqami null bo'lishi mumkin emas")
    private String twoLetter;



}
