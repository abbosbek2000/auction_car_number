package uz.developer.project.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import uz.developer.project.model.entity.RegionCarNumber;

public interface RegionCarNumberRepository extends JpaRepository<RegionCarNumber,Long> {
}
