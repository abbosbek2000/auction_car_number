package uz.developer.project.repository;

import org.springframework.context.annotation.Bean;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import uz.developer.project.model.entity.user.UserDatabase;

import java.util.Optional;

public interface UserRepository extends JpaRepository<UserDatabase,Long> {
    Optional<UserDatabase> findByUsername(String username);
}
