package uz.developer.project.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import uz.developer.project.payload.LoginDTO;
import uz.developer.project.repository.UserRepository;
@Service
public class LoginService {
    @Autowired
    UserRepository userRepository;
}
