package uz.developer.project.service;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import sun.applet.Main;
import uz.developer.project.Test;
import uz.developer.project.apiresponse.ApiResponse;
import uz.developer.project.model.entity.RegionCarNumber;
import uz.developer.project.payload.RegionCarNumberDTO;
import uz.developer.project.repository.RegionCarNumberRepository;
import uz.developer.project.repository.RegionRepository;

import java.util.Date;
import java.util.Optional;
@Service
public class RegionCarNumberService {

    private final RegionCarNumberRepository regionCarNumberRepository;
    @Autowired
    public RegionCarNumberService(RegionRepository regionRepository, RegionCarNumberRepository regionCarNumberRepository) {
        this.regionCarNumberRepository = regionCarNumberRepository;
    }

    public ApiResponse addRegionNumber(RegionCarNumberDTO regionCarNumberDTO) {
        try {
            RegionCarNumber regionCarNumber = new RegionCarNumber();
            regionCarNumber.setRegionNumber(regionCarNumberDTO.getRegionNumber());
            regionCarNumber.setFirstLetter(regionCarNumberDTO.getFirstLetter());
            regionCarNumber.setCarNumber(regionCarNumberDTO.getCarNumber());
            regionCarNumber.setTwoLetter(regionCarNumberDTO.getTwoLetter());
            regionCarNumber.setPrice(regionCarNumberDTO.getPrice());
            regionCarNumber.setAllCarNumber(regionCarNumber.getRegionNumber() + " " + regionCarNumber.getFirstLetter() + " " + regionCarNumber.getCarNumber() + " " + regionCarNumber.getTwoLetter());
            regionCarNumberRepository.save(regionCarNumber);
            return new ApiResponse("success", true);
        } catch (Exception e) {
            return new ApiResponse("error", false);
        }
    }

    public RegionCarNumber getRegionCarById(Long id) {
        Optional<RegionCarNumber> optionalRegionCarNumber = regionCarNumberRepository.findById(id);
        RegionCarNumber regionCarNumber = null;
        if (optionalRegionCarNumber.isPresent()) {
            regionCarNumber = optionalRegionCarNumber.get();

        } else {
            throw new RuntimeException("Region Car Number not found" + id);
        }
        return regionCarNumber;
    }

    public ApiResponse editRegionNumber(RegionCarNumber regionCarNumber) {
        regionCarNumber.setAllCarNumber(regionCarNumber.getRegionNumber() + " " + regionCarNumber.getFirstLetter() + " " + regionCarNumber.getRegionNumber() + " " + regionCarNumber.getTwoLetter());
        regionCarNumberRepository.save(regionCarNumber);
        return new ApiResponse("success", true);
    }

    public String deleteCarNumber(Long id) {
        regionCarNumberRepository.deleteById(id);
        return "Success";
    }




}
