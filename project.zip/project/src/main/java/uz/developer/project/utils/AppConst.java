package uz.developer.project.utils;

public interface AppConst {
    String TASHKENT = "Tashkent";
    String ANDIJON = "Andijon";
    String BUXORO = "Buxoro";
    String FERGANA = "Farg'ona";
    String JIZZAH = "Jizzah";
    String XORAZM = "Xorazm";
    String NAMANGAN = "Namangan";
    String NAVOIY = "Navoiy";
    String QASHQADARYO = "Qashqadaryo";
    String NUKUS = "Nukus";
    String SAMARQAND = "Samarqand";
    String SIRDARYO = "Sirdaryo";
    String SURXONDARYO = "Surxondaryo";
    String TOSHKENVIL = "Toshkent viloyati";


}
